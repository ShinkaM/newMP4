
/**
 * A class that runs implements several simple transformations on 2D image arrays.
 * <p>
 * This file contains stub code for your image transformation methods that are called by the main
 * class. You will do your work for this MP in this file.
 * <p>
 * Note that you can make several assumptions about the images passed to your functions, both by the
 * web front end and by our testing harness:
 * <ul>
 * <li>You will not be passed empty images.</li>
 * <li>All images will have even length and height.</li>
 * </ul>
 *
 * @see <a href="https://cs125.cs.illinois.edu/MP/4/">MP4 Documentation</a>
 */
public class Transform {

    /**
     * Default amount to shift an image's position. Not used by the testing suite, so feel free to
     * change this value.
     */
    public static final int DEFAULT_POSITION_SHIFT = 32;

    /**
     * Pixel value to use as filler when you don't have any valid data. All white with complete
     * transparency. DO NOT CHANGE THIS VALUE: the testing suite relies on it.
     */
    public static final int FILL_VALUE = 0x00FFFFFF;
    /**
     * Make a copy of the original image.
     */
    /**
     *
     * @param originalImage is the double int array that represents the individual pixels in the
     *        image.
     * @return the copied originalImage
     */
    public static int[][] copyImage(final int[][] originalImage) {
        int[][] copyImage = new int[originalImage.length][originalImage[0].length];
        for (int i = 0; i < originalImage.length; i++) {
            for (int j = 0; j < originalImage[i].length; j++) {
                copyImage[i][j] = originalImage[i][j];
            }
        }
        return copyImage;
    }
    /**
     * Shift the image left by the specified amount.
     * <p>
     * Any pixels shifted in from off screen should be filled with FILL_VALUE. This function <i>does
     * not modify the original image</i>.
     *
     * @param originalImage the image to shift to the left
     * @param amount the amount to shift the
     *        image to the left
     * @return the shifted image
     */
    public static int[][] shiftLeft(final int[][] originalImage, final int amount) {
        int[][] copyImage = new int[originalImage.length][originalImage[0].length];
        for (int i = 0; i < originalImage.length; i++) {
            for (int j = 0; j < originalImage[i].length; j++) {
                if (i + amount < originalImage.length && i + amount >= 0) {
                    copyImage[i][j] = originalImage[i + amount][j];
                } else {
                    copyImage[i][j] = FILL_VALUE;
                }
            }
        }
        return copyImage;
    }
    /*
     * Shift right like above.
     */
    /**
     *
     * @param originalImage is the double int array that represents the individual pixels in the
     *        image
     * @param amount is the amount to shift to right
     * @return the modified image, copyImage
     */
    public static int[][] shiftRight(final int[][] originalImage, final int amount) {
        int[][] copyImage = shiftLeft(originalImage, -amount);
        return copyImage;
    }

    /**
     * Shift up like above.
     */
    /**
     *
     * @param originalImage is the double int array that represents the individual pixels in the
     *        image
     * @param amount is the amount to shift up
     * @return the modified image, copyImage
     */
    public static int[][] shiftUp(final int[][] originalImage, final int amount) {
        int[][] copyImage = new int[originalImage.length][originalImage[0].length];
        for (int i = 0; i < originalImage.length; i++) {
            for (int j = 0; j < originalImage[i].length; j++) {
                if (j + amount >= 0 && j + amount < originalImage[0].length) {
                    copyImage[i][j] = originalImage[i][j + amount];
                } else {
                    copyImage[i][j] = FILL_VALUE;
                }
            }
        }
        return copyImage;
    }

    /**
     * Shift down like above.
     */
    /**
     *
     * @param originalImage is the double int array that represents the individual pixels in the
     *        image
     * @param amount is the amount to shift down
     * @return the modified image, copyImage
     */

    public static int[][] shiftDown(final int[][] originalImage, final int amount) {
        int[][] copyImage = shiftUp(originalImage, -amount);
        return copyImage;
    }
    /**
     *
     * @param length is the width or the height of the image
     * @param i is the row or column value of the double int array
     * @return the centered array index
     */
    public static double pixelXY(final int length, final double i) {
        double pixelXY = 0;
        // for the case in which x or y is negative
        if (i - (length / 2) < 0) {
            pixelXY = i - (length / 2); // length;
        } else {
            // for the case in which x or y is positive
            if (i - (length / 2) >= 0) {
                pixelXY = i - ((length / 2) - 1); // length;
            }
        }
        return pixelXY;
    }
    /**
     *
     * @param length is the width or the height of the originalImage
     * @param i is the row or column value to be modified
     * @return the centered array index
     */

    public static double fixX(final int length, final double i) {
        double fixX = 0;
        // for the case in which the original x or y value is below the midpoint
        if (i <= -1) {
            fixX = i + (length / 2);
        } else {
            // for the case in which the original x or y value is above the midpoint
            fixX = i + ((length / 2) - 1);

        }
        return fixX;
    }

    /**
     * Rotate the image left by 90 degrees around its center.
     * <p>
     * Any pixels rotated in from off screen should be filled with FILL_VALUE. This function <i>does
     * not modify the original image</i>.
     *
     * @param originalImage the image to rotate left 90 degrees
     * @return the rotated image
     */
    public static int[][] rotateLeft(final int[][] originalImage) {

        int height = originalImage[0].length;
        int width = originalImage.length;

        int[][] copyImage = new int[width][height];

        for (int i = 0; i < originalImage.length; i++) {
            for (int j = 0; j < originalImage[i].length; j++) {
                copyImage[i][j] = FILL_VALUE;
            }
        }

        for (int i = 0; i < originalImage.length; i++) {
            double tempX = pixelXY(width, i);
            for (int j = 0; j < originalImage[i].length; j++) {

                double tempY = pixelXY(height, j);

                double newX = -tempY;
                double newY = tempX;

                if ((int) fixX(width, newX) < width && (int) fixX(width, newX) >= 0
                        && (int) fixX(height, newY) < height && (int) fixX(height, newY) >= 0) {

                    copyImage[i][j] = originalImage[(int) fixX(width, newX)][(int) fixX(height,
                            newY)];

                }
            }
        }
        return copyImage;
    }

    /*
     * Rotate the image right like above.
     */
    /**
     *
     * @param originalImage is the image to be modified
     * @return the copyImage, which is the originalImage turned right
     */
    public static int[][] rotateRight(final int[][] originalImage) {

        int height = originalImage[0].length;
        int width = originalImage.length;

        int[][] copyImage = new int[width][height];

        for (int i = 0; i < originalImage.length; i++) {
            for (int j = 0; j < originalImage[i].length; j++) {
                copyImage[i][j] = FILL_VALUE;
            }
        }

        for (int i = 0; i < originalImage.length; i++) {
            double tempX = pixelXY(width, i);
            for (int j = 0; j < originalImage[i].length; j++) {
                double tempY = pixelXY(height, j);

                double newX = tempY;
                double newY = -tempX;

                if ((int) fixX(width, newX) < width && (int) fixX(width, newX) >= 0
                        && (int) fixX(height, newY) < height && (int) fixX(height, newY) >= 0) {

                    copyImage[i][j] = originalImage[(int) fixX(width, newX)][(int) fixX(height,
                            newY)];

                } else {

                    copyImage[i][j] = FILL_VALUE;
                }
            }
        }
        return copyImage;
    }

    /*
     * Flip the image on the vertical axis across its center.
     */
    /**
     *
     * @param originalImage the double int array to be modified
     * @return copyImage, the flipped originalImage
     */
    public static int[][] flipVertical(final int[][] originalImage) {

        int height = originalImage[0].length;
        int width = originalImage.length;

        int[][] copyImage = new int[width][height];

        for (int i = 0; i < originalImage.length; i++) {
            for (int j = 0; j < originalImage[i].length; j++) {
                copyImage[i][j] = FILL_VALUE;
            }
        }

        for (int i = 0; i < originalImage.length; i++) {
            double tempX = pixelXY(width, i);
            for (int j = 0; j < originalImage[i].length; j++) {

                double tempY = pixelXY(height, j);
                if ((int) fixX(width, tempX) >= 0 && (int) fixX(width, tempX) < width
                        && (int) fixX(height, -tempY) >= 0 && (int) fixX(height, -tempY) < height) {
                    copyImage[i][j] = originalImage[(int) fixX(width, tempX)][(int) fixX(height,
                            -tempY)];
                }

            }
        }
        return copyImage;
    }

    /*
     * Flip the image on the horizontal axis across its center.
     */
    /**
     *
     * @param originalImage the double int array to be modified
     * @return copyImage, the flipped image
     */
    public static int[][] flipHorizontal(final int[][] originalImage) {

        int width = originalImage.length;
        int height = originalImage[0].length;
        int[][] copyImage = new int[width][height];

        for (int i = 0; i < originalImage.length; i++) {
            for (int j = 0; j < originalImage[i].length; j++) {
                copyImage[i][j] = FILL_VALUE;
            }
        }

        for (int i = 0; i < originalImage.length; i++) {
            double tempX = pixelXY(width, i);
            for (int j = 0; j < originalImage[i].length; j++) {

                double tempY = pixelXY(height, j);
                if ((int) fixX(width, -tempX) >= 0 && (int) fixX(width, -tempX) < width
                        && (int) fixX(height, tempY) >= 0 && (int) fixX(height, tempY) < height) {
                    copyImage[i][j] = originalImage[(int) fixX(width, -tempX)][(int) fixX(height,
                            tempY)];
                }

            }
        }
        return copyImage;
    }

    /**
     * Default amount to shift colors by. Not used by the testing suite, so feel free to change this
     * value.
     */
    public static final int DEFAULT_COLOR_SHIFT = 32;
    /**
     * The amount to shift the individual components of the pixel colors.
     */
    public static final int EIGHT = 8;
    /**
     * The maximum value a color component can have.
     */
    public static final int MAXCOLOR = 255;

    /**
     * Multiply eight by this.
     */
    public static final int THREE = 3;
    // 0xAABBGGRR
    /**
     *
     * @param pixelValue the color value that the pixel in originalImage contains
     * @param alphaShift the amount to shift alpha by
     * @param blueShift the amount to shift blue by
     * @param greenShift the amount to shift green by
     * @param redShift the amount to shift red by
     * @return the modified pixel value, in int
     */
    public static int adjustColor(int pixelValue,
            final int alphaShift,
            final int blueShift,
            final int greenShift,
            final int redShift) {

        // extract the pixel value for each color;
        int alpha = ((pixelValue >>> EIGHT * THREE) & MAXCOLOR) + alphaShift;
        int blue = ((pixelValue >> EIGHT * 2) & MAXCOLOR) + blueShift;
        int green = ((pixelValue >> EIGHT) & MAXCOLOR) + greenShift;
        int red = (pixelValue & MAXCOLOR) + redShift;
        // combine the four extracted colors to represent a single pixel color
        int pixel = alpha << EIGHT * THREE | blue << EIGHT * 2
                | green << EIGHT | red;
        // apply the pixel color to the specific pixel
        pixelValue = pixel;
        return pixel;
    }

    /**
     * Add red to the image.
     * <p>
     * This function <i>does not modify the original image</i>. It should also not generate any new
     * filled pixels.
     *
     * @param originalImage the image to add red to
     * @param amount the amount of red to add
     * @return the recolored image
     */

    public static int[][] moreRed(final int[][] originalImage, final int amount) {
        int[][] copyImage = new int[originalImage.length][originalImage[0].length];
        for (int i = 0; i < originalImage.length; i++) {
            for (int j = 0; j < originalImage[i].length; j++) {
                int red = originalImage[i][j] & MAXCOLOR;
                if (red + amount <= MAXCOLOR) {
                    copyImage[i][j] = adjustColor(originalImage[i][j], 0, 0, 0, amount);
                } else {
                    copyImage[i][j] = adjustColor(originalImage[i][j], 0, 0, 0, MAXCOLOR - red);
                }
            }
        }
        return copyImage;
    }

    /*
     * Remove red from the image.
     */
    /**
     *
     * @param originalImage the double int array to be modified
     * @param amount the amount of red to subtract from the pixel
     * @return copyImage, the modified originalImage
     */
    public static int[][] lessRed(final int[][] originalImage, final int amount) {

        int[][] copyImage = new int[originalImage.length][originalImage[0].length];
        for (int i = 0; i < originalImage.length; i++) {
            for (int j = 0; j < originalImage[i].length; j++) {
                int red = (originalImage[i][j]) & MAXCOLOR;
                if (red - amount >= 0) {
                    copyImage[i][j] = adjustColor(originalImage[i][j], 0, 0, 0, -amount);
                } else {
                    copyImage[i][j] = adjustColor(originalImage[i][j], 0, 0, 0, 0 - red);
                }
            }
        }
        return copyImage;
    }

    /*
     * Add green to the image.
     */
    /**
     *
     * @param originalImage the double int array to be modified
     * @param amount the amount of green to add
     * @return copyImage, the modified originalImage
     */

    public static int[][] moreGreen(final int[][] originalImage, final int amount) {
        int[][] copyImage = new int[originalImage.length][originalImage[0].length];
        for (int i = 0; i < originalImage.length; i++) {
            for (int j = 0; j < originalImage[i].length; j++) {
                int green = (originalImage[i][j] >> EIGHT) & MAXCOLOR;
                if (green + amount <= MAXCOLOR) {
                    copyImage[i][j] = adjustColor(originalImage[i][j], 0, 0, amount, 0);
                } else {
                    copyImage[i][j] = adjustColor(originalImage[i][j], 0, 0, MAXCOLOR - green, 0);
                }
            }
        }
        return copyImage;
    }

    /*
     * Remove green from the image.
     */
    /**
     *
     * @param originalImage the double int array to be modified
     * @param amount the amount of green to subtract from the pixel
     * @return copyImage, the modified originalImage
     */
    public static int[][] lessGreen(final int[][] originalImage, final int amount) {
        int[][] copyImage = new int[originalImage.length][originalImage[0].length];
        for (int i = 0; i < originalImage.length; i++) {
            for (int j = 0; j < originalImage[i].length; j++) {
                int green = (originalImage[i][j] >> EIGHT) & MAXCOLOR;
                if (green - amount >= 0) {
                    copyImage[i][j] = adjustColor(originalImage[i][j], 0, 0, -amount, 0);
                } else {
                    copyImage[i][j] = adjustColor(originalImage[i][j], 0, 0, 0 - green, 0);
                }
            }
        }
        return copyImage;
    }

    /*
     * Add blue to the image.
     */
    /**
     *
     * @param originalImage originalImage the double int array to be modified
     * @param amount the amount of blue to add to the pixel
     * @return copyImage, the modified originalImage
     */
    public static int[][] moreBlue(final int[][] originalImage, final int amount) {
        int[][] copyImage = new int[originalImage.length][originalImage[0].length];
        for (int i = 0; i < originalImage.length; i++) {
            for (int j = 0; j < originalImage[i].length; j++) {
                int blue = (originalImage[i][j] >> EIGHT * 2) & MAXCOLOR;
                if (blue + amount <= MAXCOLOR) {
                    copyImage[i][j] = adjustColor(originalImage[i][j], 0, amount, 0, 0);
                } else {
                    copyImage[i][j] = adjustColor(originalImage[i][j], 0, MAXCOLOR - blue, 0, 0);
                }
            }
        }
        return copyImage;
    }

    /*
     * Remove blue from the image.
     */
    /**
     *
     * @param originalImage the double int array to be modified
     * @param amount the amount of blue to subtract from the image
     * @return copyImage, the modified originamImage
     */
    public static int[][] lessBlue(final int[][] originalImage, final int amount) {
        int[][] copyImage = new int[originalImage.length][originalImage[0].length];
        for (int i = 0; i < originalImage.length; i++) {
            for (int j = 0; j < originalImage[i].length; j++) {
                int blue = (originalImage[i][j] >> EIGHT * 2) & MAXCOLOR;
                if (blue - amount >= 0) {
                    copyImage[i][j] = adjustColor(originalImage[i][j], 0, -amount, 0, 0);
                } else {
                    copyImage[i][j] = adjustColor(originalImage[i][j], 0, 0 - blue, 0, 0);
                }
            }
        }
        return copyImage;
    }

    /*
     * Increase the image alpha channel.
     */
    /**
     *
     * @param originalImage the double int array to be modified
     * @param amount the amount of alpha to add to the image
     * @return copyImage, the modified originamImage
     */
    public static int[][] moreAlpha(final int[][] originalImage, final int amount) { // decrease
                                                                                    // transparency

        int[][] copyImage = new int[originalImage.length][originalImage[0].length];
        for (int i = 0; i < originalImage.length; i++) {
            for (int j = 0; j < originalImage[i].length; j++) {
                int alpha = (originalImage[i][j] >>> EIGHT * THREE) & MAXCOLOR;
                if (alpha + amount <= MAXCOLOR) {
                    copyImage[i][j] = adjustColor(originalImage[i][j], amount, 0, 0, 0);
                } else {
                    copyImage[i][j] = adjustColor(originalImage[i][j], MAXCOLOR - alpha, 0, 0, 0);
                }
            }
        }
        return copyImage;
    }

    /*
     * Decrease the image alpha channel.
     */
    /**
     *
     * @param originalImage the double int array to be modified
     * @param amount the amount of alpha to subtract from the image
     * @return copyImage, the modified originamImage
     */
    public static int[][] lessAlpha(final int[][] originalImage, final int amount) { // increase
                                                                                     // transparency
        int[][] copyImage = new int[originalImage.length][originalImage[0].length];
        for (int i = 0; i < originalImage.length; i++) {
            for (int j = 0; j < originalImage[i].length; j++) {
                int alpha = (originalImage[i][j] >>> EIGHT * THREE) & MAXCOLOR;
                if (alpha - amount >= 0) {
                    copyImage[i][j] = adjustColor(originalImage[i][j], -amount, 0, 0, 0);
                } else {
                    copyImage[i][j] = adjustColor(originalImage[i][j], 0 - alpha, 0, 0, 0);
                }
            }
        }

        return copyImage;
    }

    /**
     * The default resize factor. Not used by the testing suite, so feel free to change this value.
     */
    public static final int DEFAULT_RESIZE_AMOUNT = 2;

    /**
     * Shrink in the vertical axis around the image center.
     * <p>
     * An amount of 2 will result in an image that is half its original height. An amount of 3 will
     * result in an image that's a third of its original height. Any pixels shrunk in from off
     * screen should be filled with FILL_VALUE. This function <i>does not modify the original
     * image</i>.
     *
     * @param originalImage the image to shrink
     * @param amount the factor by which the image's height is reduced
     * @return the shrunken image
     */
    public static int[][] shrinkVertical(final int[][] originalImage, final int amount) {
        int width = originalImage.length;
        int height = originalImage[0].length;
        int[][] newCopyImage = new int[width][height];

        for (int i = 0; i < originalImage.length; i++) {
            for (int j = 0; j < originalImage[0].length; j++) {
                double tempY = pixelXY(height, j);
                if (tempY * amount > pixelXY(height, 0)
                        && tempY * amount < pixelXY(height, height)) {
                    newCopyImage[i][j] = originalImage[i][(int) fixX(height, tempY * amount)];
                } else {
                    newCopyImage[i][j] = FILL_VALUE;
                }

            }
        }
        return newCopyImage;
    }

    /*
     * Expand in the vertical axis around the image center.
     */
    /**
     *
     * @param originalImage the double int array to be modified
     * @param amount the amount to expand the image vertiacally by
     * @return copyImage, the modified originalImage
     */

    public static int[][] expandVertical(final int[][] originalImage, final int amount) {
        int width = originalImage.length;
        int height = originalImage[0].length;

        int[][] copyImage = new int[width][height];

        for (int i = 0; i < originalImage.length; i++) {

            for (int j = 0; j < originalImage[i].length; j++) {
                double tempY = pixelXY(height, j);

                copyImage[i][j] = originalImage[i][(int) Math.round(fixX(height, tempY / amount))];

            }

        }

        return copyImage;
    }

    /*
     * Shrink in the horizontal axis around the image center.
     */
    /**
     *
     * @param originalImage a double int array to be modified
     * @param amount the amount to shrink the image horizontally
     * @return copyImage, the modified originalImage
     */
    public static int[][] shrinkHorizontal(final int[][] originalImage, final int amount) {
        int width = originalImage.length;
        int height = originalImage[0].length;
        int[][] newCopyImage = new int[width][height];

        for (int i = 0; i < originalImage.length; i++) {
            for (int j = 0; j < originalImage[0].length; j++) {
                double tempX = pixelXY(width, i);
                if (tempX * amount > pixelXY(height, 0)
                        && tempX * amount < pixelXY(width, height)) {
                    newCopyImage[i][j] = originalImage[(int) fixX(width, tempX * amount)][j];
                } else {
                    newCopyImage[i][j] = FILL_VALUE;
                }

            }
        }
        return newCopyImage;
    }

    /*
     * Expand in the horizontal axis around the image center.
     */
    /**
     *
     * @param originalImage the double int array to be modified
     * @param amount the amount to expand the image horizontally by
     * @return copyImage, the modified originalImage
     */
    public static int[][] expandHorizontal(final int[][] originalImage, final int amount) {
        int width = originalImage.length;
        int height = originalImage[0].length;

        int[][] copyImage = new int[width][height];

        for (int i = 0; i < originalImage.length; i++) {
            for (int j = 0; j < originalImage[i].length; j++) {
            	
                double tempX = pixelXY(width, i);
                
                copyImage[i][j] = originalImage[(int) Math.round(fixX(width, tempX / amount))][j];

            }
        }

        return copyImage;
    }
    /**
     * Remove a green screen mask from an image.
     * <p>
     * This function should remove primarily green pixels from an image and replace them with
     * transparent pixels (FILL_VALUE), allowing you to achieve a green screen effect. Obviously
     * this function will destroy pixels, but it <i>does not modify the original image</i>.
     * <p>
     * While this function is tested by the test suite, only extreme edge cases are used. Getting it
     * work work will with real green screen images is left as a challenge for you.
     *
     * @param originalImage the image to remove a green screen from
     * @return the image with the green screen removed
     */
    // abgr
    public static final int MINRGB = 179;
    /**
     *
     * @param originalImage the double int array to be modified
     * @return copyImage, the modified originalImage
     */
    public static int[][] greenScreen(final int[][] originalImage) {
        int[][] copyImage = copyImage(originalImage);

        for (int i = 0; i < copyImage.length; i++) {
            for (int j = 0; j < copyImage[0].length; j++) {
                // int alpha = (copyImage[i][j] >> EIGHT *3) & 0xFF;
                int blue = (copyImage[i][j] >> EIGHT * 2) & MAXCOLOR;
                int green = (copyImage[i][j] >> EIGHT) & MAXCOLOR;
                int red = copyImage[i][j] & MAXCOLOR;

                if ((green <= MAXCOLOR && green >= MINRGB) && (red >= 0 && red <= MINRGB)
                        && (blue <= MINRGB && blue >= 0)) {
                    copyImage[i][j] = FILL_VALUE;
                }

            }
        }
        return copyImage;
    }

    /**
     * A wild and mysterious image transform.
     * <p>
     * You are free to implement this in any way you want. It is not tested rigorously by the test
     * suite, but it should do something (change the original image) and <i>not modify the original
     * image</i>.
     * <p>
     * Call this function mystery. It should take only the original image as a single argument and
     * return a modified image.
     *
     * @param originalImage the image to perform a strange and interesting transform on
     * @return the image transformed in wooly and frightening ways
     */

    public static int[][] mystery(final int[][] originalImage) {
        int width = originalImage.length;
        int height = originalImage[0].length;
        int[][] copyImage = new int[originalImage.length][originalImage[0].length];
        for (int i = 0; i < originalImage.length; i++) {
            for (int j = 0; j < originalImage[i].length; j++) {
                int blue = (originalImage[i][j] >> EIGHT * 2) & MAXCOLOR;
                int green = (originalImage[i][j] >> EIGHT) & MAXCOLOR;
                int red = originalImage[i][j] & MAXCOLOR;

                int average = ((blue + green + red) / THREE);
                int newPixel = average << EIGHT * THREE | average << EIGHT * 2 | average << EIGHT
                        | average;

                copyImage[i][j] = newPixel;
            }
        }
        int[][] newCopyImage = new int[width][height];
        int amount = 2 * 2;
        for (int i = 0; i < originalImage.length; i++) {
            for (int j = height / 2; j >= 0; j--) {
                double tempY = pixelXY(height, j);
                if (tempY - amount > pixelXY(height, 0)) {
                    newCopyImage[i][j] = copyImage[i][(int) fixX(height, tempY - amount)];
                }
            }
            for (int k = height / 2; k < height; k++) {
                double tempY = pixelXY(height, k);
                if (tempY + amount < pixelXY(height, height)) {
                    newCopyImage[i][k] = copyImage[i][(int) fixX(height, tempY + amount)];
                }
            }
        }
        return newCopyImage;
    }

}
